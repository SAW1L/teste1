#!/bin/bash

mvn javadoc:javadoc -Dmaven.javadoc.failOnError=false
